
admin<br>
<a href="{{route('admin1')}}">admin1</a><br>
<a href="{{route('admin2')}}">admin2</a><br>
<a href="{{route('admin3')}}">admin3</a><br>

student<br>
<a href="{{route('student1')}}">student1</a><br>
<a href="{{route('student2')}}">student2</a><br>
<a href="{{route('student3')}}">student3</a><br>
<a href="{{route('student4')}}">student4</a>
<a href="javascript:;" onclick="event.preventDefault();document.querySelector('#logout-form').submit();">logout</a>
                                    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                        @csrf